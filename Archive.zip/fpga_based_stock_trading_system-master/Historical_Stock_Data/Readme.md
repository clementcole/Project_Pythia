The following are historical data for amd, facebook, apple ....  from 2011-01-01  to 2016-06-31 except for facebook since facebook's
stocks became public at around 2012. 

thanks.
